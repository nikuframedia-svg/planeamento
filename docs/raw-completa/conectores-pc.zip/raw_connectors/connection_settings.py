import os
from types import SimpleNamespace
settings=SimpleNamespace(cpis_dsn=os.environ.get('CPIS_DSN',''),pg_dsn=os.environ.get('CPIS_PUBLISH_DSN',''))
