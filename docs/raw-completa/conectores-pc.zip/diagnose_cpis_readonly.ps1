param(
    [Parameter(Mandatory = $true)][string]$Workbook,
    [string]$OutputPath = (Join-Path $PSScriptRoot 'logs\cpis-readonly-diagnostic.json')
)

# Run on the same Windows PC and user account that refreshes the workbook.
# Reads its saved ODBC connection, uses the existing CPIS DSN, and performs
# SELECTs in a read-only transaction. Never prints the connection string.
# No Excel automation, macros, source changes, or central publication.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.Data

$report = [ordered]@{
    observed_at_utc = [DateTime]::UtcNow.ToString('o')
    workbook = [IO.Path]::GetFileName($Workbook)
    process_64_bit = [Environment]::Is64BitProcess
    source = 'ODBC connection stored in workbook'
    success = $false
    checks = [ordered]@{}
}
$connection = $null
$transaction = $null
$stage = 'read_workbook_connection'
$exitCode = 1

function Read-CpisQuery([string]$Sql) {
    $command = $connection.CreateCommand()
    $command.Transaction = $transaction
    $command.CommandTimeout = 60
    $command.CommandText = $Sql
    $reader = $null
    try {
        $reader = $command.ExecuteReader()
        $items = [Collections.Generic.List[object]]::new()
        while ($reader.Read()) {
            $row = [ordered]@{}
            for ($index = 0; $index -lt $reader.FieldCount; $index++) {
                $value = $reader.GetValue($index)
                if ($value -is [DBNull]) { $value = $null }
                # Do not assign a timezone to source timestamps.
                if ($value -is [DateTime]) { $value = $value.ToString('yyyy-MM-dd HH:mm:ss.fffffff') }
                $row[$reader.GetName($index)] = $value
            }
            $items.Add($row)
        }
        return ,$items.ToArray()
    } finally {
        if ($reader) { $reader.Dispose() }
        $command.Dispose()
    }
}

try {
    $archive = [IO.Compression.ZipFile]::OpenRead((Resolve-Path $Workbook).Path)
    try {
        $entry = $archive.GetEntry('xl/connections.xml')
        if (-not $entry) { throw 'Missing workbook connections' }
        $stream = [IO.StreamReader]::new($entry.Open())
        try { [xml]$xml = $stream.ReadToEnd() } finally { $stream.Dispose() }
        $nodes = @($xml.SelectNodes("//*[local-name()='dbPr']") | Where-Object {
            $_.GetAttribute('command') -match 'ordensfabrico_listagem_excel_vw'
        })
        if ($nodes.Count -ne 1) { throw 'Expected exactly one CPIS order connection' }
        $builder = [Data.Odbc.OdbcConnectionStringBuilder]::new($nodes[0].GetAttribute('connection'))
        foreach ($key in @('DSN','SERVER','PORT','DATABASE')) {
            if ($builder.ContainsKey($key)) { $report[$key.ToLowerInvariant()] = $builder[$key] }
        }
        $report['embedded_password_present'] = $builder.ContainsKey('PWD') -or $builder.ContainsKey('Password')
        $report['excel_query_has_old_of_filter'] = $nodes[0].GetAttribute('command') -match '>\s*250000'
        $builder['ReadOnly'] = '1'
        $connection = [Data.Odbc.OdbcConnection]::new($builder.ConnectionString)
    } finally { $archive.Dispose() }

    $stage = 'open_odbc'
    $connection.Open()
    $stage = 'begin_readonly_transaction'
    $transaction = $connection.BeginTransaction([Data.IsolationLevel]::RepeatableRead)
    $command = $connection.CreateCommand()
    try {
        $command.Transaction = $transaction
        $command.CommandText = 'SET TRANSACTION READ ONLY'
        [void]$command.ExecuteNonQuery()
    } finally { $command.Dispose() }

    $stage = 'verify_database'
    $report.checks['connection'] = Read-CpisQuery @'
SELECT current_database() AS database_name,
       inet_server_addr()::text AS server_address,
       current_setting('transaction_read_only') AS read_only,
       current_setting('transaction_isolation') AS isolation,
       current_setting('TimeZone') AS session_timezone
'@
    if ($report.checks.connection[0].database_name -ne 'cpis' -or
        $report.checks.connection[0].read_only -ne 'on') { throw 'Wrong database or writable transaction' }

    $stage = 'read_order_view'
    $report.checks['order_columns'] = Read-CpisQuery @'
SELECT column_name,data_type FROM information_schema.columns
WHERE table_schema='public' AND table_name='ordensfabrico_listagem_excel_vw'
ORDER BY ordinal_position
'@
    $report.checks['order_counts'] = Read-CpisQuery @'
SELECT status,count(*) AS rows,count(DISTINCT of) AS distinct_orders
FROM public.ordensfabrico_listagem_excel_vw GROUP BY status ORDER BY status
'@
    $report.checks['multiple_rows_per_order'] = Read-CpisQuery @'
SELECT count(*) AS orders_with_multiple_rows FROM (
 SELECT of FROM public.ordensfabrico_listagem_excel_vw GROUP BY of HAVING count(*)>1
) duplicates
'@
    $report.checks['example_order_states'] = Read-CpisQuery @'
SELECT of,ov,status,datafimprevdp,dataentregadl
FROM public.ordensfabrico_listagem_excel_vw
WHERE of IN ('OF266229','OF266198','OF264760','OF264763') ORDER BY of,ov
'@

    $stage = 'read_picking_view'
    $report.checks['picking_columns'] = Read-CpisQuery @'
SELECT column_name,data_type FROM information_schema.columns
WHERE table_schema='mtg2' AND table_name='pickingprodcab_pesq_vw'
ORDER BY ordinal_position
'@
    $report.checks['picking_counts'] = Read-CpisQuery @'
SELECT count(*) AS rows,count(DISTINCT of) AS distinct_orders,
       count(*) FILTER(WHERE semana=0) AS no_week_assigned
FROM mtg2.pickingprodcab_pesq_vw
'@
    $report.checks['related_accessible_views'] = Read-CpisQuery @'
SELECT table_schema,table_name FROM information_schema.views
WHERE table_schema IN ('public','mtg2')
AND (table_name LIKE '%ordensfabric%' OR table_name LIKE '%picking%'
     OR table_name LIKE '%desenho%' OR table_name LIKE '%material%'
     OR table_name LIKE '%operac%' OR table_name LIKE '%peca%')
ORDER BY table_schema,table_name
'@
    $report['success'] = $true
    $exitCode = 0
} catch {
    $report['failed_stage'] = $stage
    # SQLSTATE and native code are sufficient to distinguish a missing DSN,
    # network timeout, authentication, and missing permissions without secrets.
    $cause = $_.Exception
    while ($cause.InnerException) { $cause = $cause.InnerException }
    $report['error_type'] = $cause.GetType().FullName
    if ($cause -is [Data.Odbc.OdbcException]) {
        $report['odbc_errors'] = @($cause.Errors | ForEach-Object {
            @{ sql_state = $_.SQLState; native_error = $_.NativeError }
        })
    }
} finally {
    if ($transaction) { try { $transaction.Rollback() } catch {}; $transaction.Dispose() }
    if ($connection) { $connection.Dispose() }
    $report['finished_at_utc'] = [DateTime]::UtcNow.ToString('o')
    $absoluteOutput = [IO.Path]::GetFullPath($OutputPath)
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($absoluteOutput))
    $report | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $absoluteOutput -Encoding UTF8
    Write-Host "CPIS read-only diagnostic saved: $absoluteOutput"
    Write-Host "Success: $($report.success)"
    if (-not $report.success) { Write-Host "Failed stage: $($report.failed_stage)" }
}
exit $exitCode
