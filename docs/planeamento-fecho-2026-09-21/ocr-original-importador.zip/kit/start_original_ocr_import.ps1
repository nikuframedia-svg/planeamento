# Unidirectional: original SQLite (read-only) -> central PostgreSQL.
param([string]$Repo = "C:\OCR-Suite\kanban-mes-mtg2", [switch]$Check)
$ErrorActionPreference = "Stop"
$config = Join-Path $PSScriptRoot "original-ocr-import.env"
if (-not (Test-Path -LiteralPath $config)) { throw "Configura original-ocr-import.env a partir do exemplo." }
Get-Content -LiteralPath $config | ForEach-Object {
    $line = $_.Trim()
    if ($line -and -not $line.StartsWith('#') -and $line.Contains('=')) {
        $idx = $line.IndexOf('=')
        Set-Item -Path ("Env:" + $line.Substring(0,$idx).Trim()) -Value $line.Substring($idx+1).Trim().Trim('"').Trim("'")
    }
}
$python = Join-Path $Repo '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $python)) { throw "Python da aplicação não encontrado." }
if (-not (Test-Path -LiteralPath $env:ORIGINAL_OCR_SQLITE_PATH -PathType Leaf)) { throw "Confirma o caminho da base SQLite usada pelo OCR original." }
Set-Location $Repo
if ($Check) { & $python -m app.original_ocr --check; exit $LASTEXITCODE }
$logs = Join-Path $PSScriptRoot 'logs'
New-Item -ItemType Directory -Force -Path $logs | Out-Null
& $python -m app.original_ocr --watch *>> (Join-Path $logs 'original-ocr-import.log')
exit $LASTEXITCODE
